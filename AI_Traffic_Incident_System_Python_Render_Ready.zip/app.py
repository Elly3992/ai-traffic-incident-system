import os
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv
import mysql.connector
from mysql.connector import Error
from ai.classifier import IncidentClassifier
from ai.duplicate_detector import find_duplicates

load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "change-this-secret-key")

DB_CONFIG = {
    "host": os.getenv("DB_HOST", "127.0.0.1"),
    "port": int(os.getenv("DB_PORT", "3306")),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD", ""),
    "database": os.getenv("DB_NAME", "traffic_incident_system"),
}

classifier = IncidentClassifier()

def get_db():
    return mysql.connector.connect(**DB_CONFIG)

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped

def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if session.get("role") != "ADMIN":
            flash("Administrator access required.", "danger")
            return redirect(url_for("dashboard"))
        return view(*args, **kwargs)
    return wrapped

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("full_name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        if not name or not email or not password:
            flash("All fields are required.", "danger")
            return redirect(url_for("register"))

        conn = get_db()
        cur = conn.cursor(dictionary=True)
        cur.execute("SELECT id FROM users WHERE email=%s", (email,))
        if cur.fetchone():
            cur.close(); conn.close()
            flash("Email is already registered.", "warning")
            return redirect(url_for("register"))

        cur.execute(
            "INSERT INTO users (full_name,email,password_hash,role) VALUES (%s,%s,%s,'USER')",
            (name, email, generate_password_hash(password))
        )
        conn.commit()
        cur.close(); conn.close()

        flash("Account created successfully. Please log in.", "success")
        return redirect(url_for("login"))

    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        conn = get_db()
        cur = conn.cursor(dictionary=True)
        cur.execute("SELECT * FROM users WHERE email=%s", (email,))
        user = cur.fetchone()
        cur.close(); conn.close()

        if user and check_password_hash(user["password_hash"], password):
            session["user_id"] = user["id"]
            session["full_name"] = user["full_name"]
            session["role"] = user["role"]
            return redirect(url_for("admin_dashboard" if user["role"] == "ADMIN" else "dashboard"))

        flash("Invalid email or password.", "danger")

    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/dashboard")
@login_required
def dashboard():
    conn = get_db()
    cur = conn.cursor(dictionary=True)
    cur.execute("""
        SELECT i.*, c.name AS category_name
        FROM incidents i
        LEFT JOIN categories c ON i.category_id=c.id
        WHERE i.user_id=%s
        ORDER BY i.created_at DESC
    """, (session["user_id"],))
    incidents = cur.fetchall()
    cur.close(); conn.close()
    return render_template("dashboard.html", incidents=incidents)

@app.route("/report", methods=["GET", "POST"])
@login_required
def report():
    if request.method == "POST":
        description = request.form.get("description", "").strip()
        location = request.form.get("location", "").strip()
        latitude = request.form.get("latitude") or None
        longitude = request.form.get("longitude") or None

        if not description or not location:
            flash("Description and location are required.", "danger")
            return redirect(url_for("report"))

        category_name, confidence = classifier.predict(description)

        conn = get_db()
        cur = conn.cursor(dictionary=True)
        cur.execute("SELECT id FROM categories WHERE name=%s", (category_name,))
        category = cur.fetchone()

        cur.execute("""
            INSERT INTO incidents
            (user_id, category_id, description, location, latitude, longitude, ai_confidence, status)
            VALUES (%s,%s,%s,%s,%s,%s,%s,'PENDING')
        """, (
            session["user_id"], category["id"] if category else None,
            description, location, latitude, longitude, confidence
        ))
        incident_id = cur.lastrowid

        # Compare the new report with previous reports.
        cur.execute("""
            SELECT id, description, latitude, longitude
            FROM incidents
            WHERE id != %s
            ORDER BY created_at DESC
            LIMIT 500
        """, (incident_id,))
        previous = cur.fetchall()

        matches = find_duplicates(
            description,
            latitude,
            longitude,
            previous,
            threshold=0.70
        )

        for match in matches:
            cur.execute("""
                INSERT INTO duplicate_matches
                (incident_id, matched_incident_id, similarity_score, review_status)
                VALUES (%s,%s,%s,'PENDING')
            """, (incident_id, match["id"], match["score"]))

        conn.commit()
        cur.close(); conn.close()

        flash(
            f"Incident submitted. AI category: {category_name} "
            f"({confidence:.0%} confidence).",
            "success"
        )
        return redirect(url_for("dashboard"))

    return render_template("report.html")

@app.route("/admin")
@admin_required
def admin_dashboard():
    conn = get_db()
    cur = conn.cursor(dictionary=True)

    cur.execute("""
        SELECT i.*, u.full_name, u.email, c.name AS category_name
        FROM incidents i
        JOIN users u ON i.user_id=u.id
        LEFT JOIN categories c ON i.category_id=c.id
        ORDER BY i.created_at DESC
    """)
    incidents = cur.fetchall()

    cur.execute("SELECT COUNT(*) AS total FROM incidents")
    total = cur.fetchone()["total"]
    cur.execute("SELECT COUNT(*) AS pending FROM incidents WHERE status='PENDING'")
    pending = cur.fetchone()["pending"]
    cur.execute("SELECT COUNT(*) AS resolved FROM incidents WHERE status='RESOLVED'")
    resolved = cur.fetchone()["resolved"]

    cur.close(); conn.close()

    return render_template(
        "admin/dashboard.html",
        incidents=incidents,
        total=total,
        pending=pending,
        resolved=resolved
    )

@app.route("/admin/incident/<int:incident_id>/status", methods=["POST"])
@admin_required
def update_status(incident_id):
    new_status = request.form.get("status")
    comment = request.form.get("comment", "").strip()

    allowed = {"PENDING", "UNDER REVIEW", "IN PROGRESS", "RESOLVED", "REJECTED"}
    if new_status not in allowed:
        flash("Invalid status.", "danger")
        return redirect(url_for("admin_dashboard"))

    conn = get_db()
    cur = conn.cursor(dictionary=True)
    cur.execute("SELECT status FROM incidents WHERE id=%s", (incident_id,))
    incident = cur.fetchone()

    if not incident:
        cur.close(); conn.close()
        flash("Incident not found.", "danger")
        return redirect(url_for("admin_dashboard"))

    old_status = incident["status"]
    cur.execute(
        "UPDATE incidents SET status=%s, updated_at=CURRENT_TIMESTAMP WHERE id=%s",
        (new_status, incident_id)
    )
    cur.execute("""
        INSERT INTO incident_updates
        (incident_id, admin_id, old_status, new_status, comment)
        VALUES (%s,%s,%s,%s,%s)
    """, (incident_id, session["user_id"], old_status, new_status, comment))

    conn.commit()
    cur.close(); conn.close()
    flash("Incident status updated.", "success")
    return redirect(url_for("admin_dashboard"))

@app.route("/api/health")
def health():
    try:
        conn = get_db()
        conn.close()
        return jsonify({"status": "ok", "database": "connected"})
    except Error as e:
        return jsonify({"status": "error", "database": str(e)}), 500

if __name__ == "__main__":
    port = int(os.getenv("PORT", "5000"))
    app.run(host="0.0.0.0", port=port, debug=os.getenv("FLASK_DEBUG", "false").lower() == "true")
