# AI Traffic Incident Reporting System - Python Version

## Technology
- Python 3
- Flask
- MySQL/MariaDB
- mysql-connector-python
- scikit-learn
- TF-IDF + Logistic Regression
- TF-IDF cosine similarity for duplicate detection
- HTML/CSS/Bootstrap

## 1. Create virtual environment

```bash
python -m venv venv
source venv/bin/activate
```

## 2. Install packages

```bash
pip install -r requirements.txt
```

## 3. Create database

Start MariaDB/MySQL and run:

```bash
mysql -u root -p < database/schema.sql
```

If your system uses MariaDB, the command is usually the same.

## 4. Configure environment

Copy `.env.example` to `.env`:

```bash
cp .env.example .env
```

Edit the password if your database root user has a password.

## 5. Run

```bash
python app.py
```

Open:

http://127.0.0.1:5000

Test the connection:

http://127.0.0.1:5000/api/health

Expected:

```json
{"status":"ok","database":"connected"}
```

## 6. Create an administrator

First register a normal account through the website.

Then run:

```sql
USE traffic_incident_system;
UPDATE users SET role='ADMIN' WHERE email='your-email@example.com';
```

Log out and log in again. You will be redirected to the admin dashboard.

## AI implementation

The prototype automatically:
1. Reads the incident description.
2. Converts text into TF-IDF features.
3. Uses Logistic Regression to classify the incident.
4. Stores the predicted category and confidence.
5. Compares the new description with previous reports using cosine similarity.
6. Uses location proximity as an additional signal when coordinates are supplied.
7. Stores possible duplicate matches for later administrative review.

The AI is a prototype and should not be presented as a production traffic-management system without a larger validated dataset.


## Render deployment

This repository includes `render.yaml`, `RENDER_DEPLOY.md`, and Gunicorn configuration for deployment. The hosted web service requires a separately hosted MySQL database; configure its connection details through Render environment variables.
