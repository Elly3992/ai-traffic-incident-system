import os
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

MODEL_DIR = os.path.join(os.path.dirname(__file__), "model")
MODEL_FILE = os.path.join(MODEL_DIR, "classifier.joblib")

TRAINING_DATA = {
    "Road Accident": [
        "two cars have collided on the highway",
        "there has been a serious vehicle crash",
        "motorcycle accident near the junction",
        "vehicles involved in an accident",
        "car overturned after a collision",
        "lorry crashed into another vehicle",
    ],
    "Pothole": [
        "large pothole on the road",
        "deep potholes are damaging vehicles",
        "there is a dangerous pothole ahead",
        "road surface has a big pothole",
        "multiple potholes near the market",
        "huge pothole in the left lane",
    ],
    "Flooding": [
        "road is flooded after heavy rain",
        "water has covered the road",
        "flood water is blocking the highway",
        "deep water on the road",
        "flooding has made the road impassable",
        "rain water is covering the junction",
    ],
    "Road Obstruction": [
        "fallen tree is blocking the road",
        "debris is blocking the highway",
        "rocks are blocking the road",
        "road is blocked by construction materials",
        "a truck is blocking one lane",
        "obstruction on the main road",
    ],
    "Vehicle Breakdown": [
        "broken down vehicle is on the roadside",
        "bus has broken down in the lane",
        "vehicle stopped due to mechanical failure",
        "car has broken down on the highway",
        "lorry breakdown causing traffic",
        "disabled vehicle is blocking traffic",
    ],
    "Damaged Traffic Infrastructure": [
        "traffic light is not working",
        "damaged road sign at the junction",
        "street light pole has fallen",
        "broken traffic signal",
        "guardrail has been damaged",
        "road sign has been knocked down",
    ],
    "Other": [
        "there is an unusual issue on the road",
        "traffic situation needs attention",
        "something is wrong along the road",
        "road users need assistance",
        "incident reported near the town",
        "please investigate this road problem",
    ],
}

class IncidentClassifier:
    def __init__(self):
        os.makedirs(MODEL_DIR, exist_ok=True)
        self.vectorizer = TfidfVectorizer(ngram_range=(1, 2), lowercase=True)
        self.model = LogisticRegression(max_iter=2000)
        self._train()

    def _train(self):
        texts, labels = [], []
        for label, examples in TRAINING_DATA.items():
            for text in examples:
                texts.append(text)
                labels.append(label)

        X = self.vectorizer.fit_transform(texts)
        self.model.fit(X, labels)

        # Save local model artifacts for demonstration and future expansion.
        joblib.dump(
            {"vectorizer": self.vectorizer, "model": self.model},
            MODEL_FILE
        )

    def predict(self, text):
        X = self.vectorizer.transform([text])
        probabilities = self.model.predict_proba(X)[0]
        index = probabilities.argmax()
        return self.model.classes_[index], float(probabilities[index])
