from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import math

def _distance_km(lat1, lon1, lat2, lon2):
    try:
        lat1, lon1, lat2, lon2 = map(float, [lat1, lon1, lat2, lon2])
    except (TypeError, ValueError):
        return None

    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return 2 * r * math.asin(math.sqrt(a))

def find_duplicates(description, latitude, longitude, previous_incidents, threshold=0.70):
    if not previous_incidents:
        return []

    texts = [description] + [x["description"] for x in previous_incidents]
    vectorizer = TfidfVectorizer(ngram_range=(1, 2), lowercase=True)
    matrix = vectorizer.fit_transform(texts)
    scores = cosine_similarity(matrix[0:1], matrix[1:]).flatten()

    matches = []
    for incident, text_score in zip(previous_incidents, scores):
        distance = _distance_km(
            latitude, longitude,
            incident.get("latitude"), incident.get("longitude")
        )

        # Text similarity is primary. If both reports have coordinates and
        # are within 1 km, a slightly lower text threshold is accepted.
        effective_threshold = 0.60 if distance is not None and distance <= 1.0 else threshold

        if text_score >= effective_threshold:
            matches.append({
                "id": incident["id"],
                "score": round(float(text_score), 4),
                "distance_km": round(distance, 3) if distance is not None else None
            })

    return sorted(matches, key=lambda x: x["score"], reverse=True)
