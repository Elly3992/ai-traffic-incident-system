# Render Deployment Guide

## Important
This application uses Flask + MySQL. Render hosts the Flask web service, but the MySQL database must be hosted by a separate MySQL provider. Do not use `127.0.0.1` as the database host on Render.

## 1. Put the project on GitHub
Create a GitHub repository and upload all files in this folder. Do not upload `.env` or passwords.

## 2. Create the MySQL database
Use a MySQL-compatible hosted database provider. Create a database named `traffic_incident_system`, then run `database/schema.sql` against it. Keep the database host, port, username, password and database name.

## 3. Deploy the web service on Render
Create a new Web Service from your GitHub repository.

Build Command:
```
pip install -r requirements.txt
```

Start Command:
```
gunicorn app:app
```

## 4. Add environment variables
In Render, add:

```text
SECRET_KEY=<long-random-secret>
DB_HOST=<host-from-your-mysql-provider>
DB_PORT=3306
DB_USER=<mysql-user>
DB_PASSWORD=<mysql-password>
DB_NAME=traffic_incident_system
```

## 5. Test
After deployment, open:

```text
https://YOUR-RENDER-SERVICE.onrender.com/api/health
```

It should return:

```json
{"status":"ok","database":"connected"}
```

Then open the root URL to use the system.

## Local development
For local development, copy `.env.example` to `.env` and set the values for your local MySQL/MariaDB server.
